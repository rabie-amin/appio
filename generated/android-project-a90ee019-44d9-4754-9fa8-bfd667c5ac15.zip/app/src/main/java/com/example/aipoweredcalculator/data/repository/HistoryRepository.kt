package com.example.aipoweredcalculator.data.repository

import com.example.aipoweredcalculator.data.model.CalculationHistory
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.Query
import kotlinx.coroutines.tasks.await
import javax.inject.Inject

class HistoryRepository @Inject constructor(
    private val auth: FirebaseAuth,
    private val firestore: FirebaseFirestore
) {
    private val userId: String?
        get() = auth.currentUser?.uid

    private fun getHistoryCollection() = firestore.collection("history")

    suspend fun getHistory(): List<CalculationHistory> {
        val currentUserId = userId ?: return emptyList()
        return try {
            getHistoryCollection()
                .whereEqualTo("userId", currentUserId)
                .orderBy("timestamp", Query.Direction.DESCENDING)
                .get()
                .await()
                .toObjects(CalculationHistory::class.java)
        } catch (e: Exception) {
            emptyList()
        }
    }

    suspend fun addHistoryItem(item: CalculationHistory) {
        val currentUserId = userId ?: return
        try {
            val docRef = getHistoryCollection().document()
            val newItem = item.copy(id = docRef.id, userId = currentUserId)
            docRef.set(newItem).await()
        } catch (_: Exception) {}
    }

    suspend fun deleteHistoryItem(itemId: String) {
        try {
            getHistoryCollection().document(itemId).delete().await()
        } catch (_: Exception) {}
    }

    suspend fun clearHistory() {
        val currentUserId = userId ?: return
        try {
            val batch = firestore.batch()
            val querySnapshot = getHistoryCollection()
                .whereEqualTo("userId", currentUserId)
                .get()
                .await()
            for (document in querySnapshot.documents) {
                batch.delete(document.reference)
            }
            batch.commit().await()
        } catch (_: Exception) {}
    }
}