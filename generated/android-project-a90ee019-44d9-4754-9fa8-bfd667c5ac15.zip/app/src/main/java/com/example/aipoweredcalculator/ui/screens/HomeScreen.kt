package com.example.aipoweredcalculator.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Backspace
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Info
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.navigation.NavController
import com.example.aipoweredcalculator.navigation.AppScreens
import com.example.aipoweredcalculator.viewmodel.CalculatorAction
import com.example.aipoweredcalculator.viewmodel.CalculatorViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(navController: NavController, viewModel: CalculatorViewModel = hiltViewModel()) {
    val expression by viewModel.expression.collectAsState()
    val result by viewModel.result.collectAsState()

    val buttons = listOf(
        "AC", "C", "%", "÷",
        "7", "8", "9", "×",
        "4", "5", "6", "–",
        "1", "2", "3", "+",
        "0", ".", "="
    )

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Calculator") },
                actions = {
                    IconButton(onClick = { navController.navigate(AppScreens.About.route) }) {
                        Icon(Icons.Default.Info, contentDescription = "About")
                    }
                }
            )
        },
        floatingActionButton = {
            FloatingActionButton(onClick = { navController.navigate(AppScreens.AiCalculator.route) }) {
                Icon(Icons.Default.AutoAwesome, contentDescription = "AI Mode")
            }
        }
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .padding(16.dp),
            verticalArrangement = Arrangement.Bottom
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                horizontalAlignment = Alignment.End,
                verticalArrangement = Arrangement.Bottom
            ) {
                Text(text = expression, style = MaterialTheme.typography.headlineMedium, maxLines = 2, textAlign = TextAlign.End)
                Text(text = result, style = MaterialTheme.typography.displayMedium, maxLines = 1, textAlign = TextAlign.End)
            }

            Spacer(modifier = Modifier.height(16.dp))

            LazyVerticalGrid(
                columns = GridCells.Fixed(4),
                verticalArrangement = Arrangement.spacedBy(8.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(buttons) { button ->
                    CalculatorButton(text = button, onClick = {
                        handleButtonClick(button, viewModel)
                    })
                }
                item {
                     CalculatorButton(
                        icon = Icons.AutoMirrored.Filled.Backspace,
                        onClick = { viewModel.onAction(CalculatorAction.Delete) }
                    )
                }
            }
        }
    }
}

fun handleButtonClick(button: String, viewModel: CalculatorViewModel) {
    when (button) {
        "AC" -> viewModel.onAction(CalculatorAction.Clear)
        "=" -> viewModel.onAction(CalculatorAction.Calculate)
        "." -> viewModel.onAction(CalculatorAction.Decimal)
        in "0".."9" -> viewModel.onAction(CalculatorAction.Number(button))
        else -> viewModel.onAction(CalculatorAction.Operation(button))
    }
}

@Composable
fun CalculatorButton(text: String? = null, icon: ImageVector? = null, onClick: () -> Unit) {
    val isOperator = text in listOf("÷", "×", "–", "+", "=")
    val isClear = text == "AC"

    val containerColor = when {
        isClear -> MaterialTheme.colorScheme.errorContainer
        isOperator -> MaterialTheme.colorScheme.primaryContainer
        else -> MaterialTheme.colorScheme.secondaryContainer
    }
    val contentColor = when {
        isClear -> MaterialTheme.colorScheme.onErrorContainer
        isOperator -> MaterialTheme.colorScheme.onPrimaryContainer
        else -> MaterialTheme.colorScheme.onSecondaryContainer
    }

    Box(
        modifier = Modifier
            .clip(CircleShape)
            .background(containerColor)
            .clickable(onClick = onClick)
            .aspectRatio(1f),
        contentAlignment = Alignment.Center
    ) {
        if (text != null) {
            Text(
                text = text,
                fontSize = 24.sp,
                color = contentColor
            )
        } else if (icon != null) {
            Icon(imageVector = icon, contentDescription = null, tint = contentColor)
        }
    }
}