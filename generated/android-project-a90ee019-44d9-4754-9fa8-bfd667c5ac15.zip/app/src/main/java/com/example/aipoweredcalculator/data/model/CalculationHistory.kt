package com.example.aipoweredcalculator.data.model

import com.google.firebase.firestore.ServerTimestamp
import java.util.Date

data class CalculationHistory(
    val id: String = "",
    val userId: String = "",
    val query: String = "",
    val result: String = "",
    val isAiCalculation: Boolean = false,
    @ServerTimestamp val timestamp: Date? = null
)