package com.example.aipoweredcalculator.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.aipoweredcalculator.data.repository.AuthRepository
import com.example.aipoweredcalculator.utils.Result
import com.google.firebase.auth.FirebaseUser
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class AuthViewModel @Inject constructor(private val repository: AuthRepository) : ViewModel() {

    private val _authState = MutableStateFlow<Result<FirebaseUser?>>(Result.Success(repository.getCurrentUser()))
    val authState: StateFlow<Result<FirebaseUser?>> = _authState

    fun signIn(email: String, pass: String) {
        viewModelScope.launch {
            _authState.value = Result.Loading
            _authState.value = repository.signIn(email, pass)
        }
    }

    fun signUp(email: String, pass: String) {
        viewModelScope.launch {
            _authState.value = Result.Loading
            _authState.value = repository.signUp(email, pass)
        }
    }

    fun signOut() {
        viewModelScope.launch {
            repository.signOut()
            _authState.value = Result.Success(null)
        }
    }
}