package com.example.aipoweredcalculator.navigation

sealed class AppScreens(val route: String) {
    object Splash : AppScreens("splash_screen")
    object Auth : AppScreens("auth_screen")
    object Main : AppScreens("main_screen")
    object Home : AppScreens("home_screen")
    object AiCalculator : AppScreens("ai_calculator_screen")
    object History : AppScreens("history_screen")
    object Settings : AppScreens("settings_screen")
    object About : AppScreens("about_screen")
}