package com.example.aipoweredcalculator.ui.screens

import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.navigation.NavDestination.Companion.hierarchy
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.*
import com.example.aipoweredcalculator.navigation.AppScreens

sealed class BottomNavItem(val screen: AppScreens, val icon: ImageVector, val label: String) {
    object Home : BottomNavItem(AppScreens.Home, Icons.Default.Home, "Home")
    object History : BottomNavItem(AppScreens.History, Icons.Default.History, "History")
    object Settings : BottomNavItem(AppScreens.Settings, Icons.Default.Settings, "Settings")
}

@Composable
fun MainScreen() {
    val navController = rememberNavController()

    Scaffold(
        bottomBar = {
            val navBackStackEntry by navController.currentBackStackEntryAsState()
            val currentDestination = navBackStackEntry?.destination

            NavigationBar {
                val items = listOf(BottomNavItem.Home, BottomNavItem.History, BottomNavItem.Settings)
                items.forEach { item ->
                    NavigationBarItem(
                        icon = { Icon(item.icon, contentDescription = item.label) },
                        label = { Text(item.label) },
                        selected = currentDestination?.hierarchy?.any { it.route == item.screen.route } == true,
                        onClick = {
                            navController.navigate(item.screen.route) {
                                popUpTo(navController.graph.findStartDestination().id) {
                                    saveState = true
                                }
                                launchSingleTop = true
                                restoreState = true
                            }
                        }
                    )
                }
            }
        }
    ) {\innerPadding ->
        NavHost(navController, startDestination = AppScreens.Home.route, Modifier.padding(innerPadding)) {
            composable(AppScreens.Home.route) { HomeScreen(navController) }
            composable(AppScreens.History.route) { HistoryScreen(navController) }
            composable(AppScreens.Settings.route) { SettingsScreen(navController) }
            composable(AppScreens.AiCalculator.route) { AiCalculatorScreen(navController) }
            composable(AppScreens.About.route) { AboutScreen(navController) }
        }
    }
}