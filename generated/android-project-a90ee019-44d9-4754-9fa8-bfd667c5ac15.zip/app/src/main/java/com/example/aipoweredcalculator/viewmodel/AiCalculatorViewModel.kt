package com.example.aipoweredcalculator.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.aipoweredcalculator.data.model.CalculationHistory
import com.example.aipoweredcalculator.data.repository.HistoryRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class AiCalculatorViewModel @Inject constructor(
    private val historyRepository: HistoryRepository
) : ViewModel() {

    private val _uiState = MutableStateFlow(AiCalculatorUiState())
    val uiState: StateFlow<AiCalculatorUiState> = _uiState

    fun submitQuery(query: String) {
        if (query.isBlank()) return

        viewModelScope.launch {
            _uiState.value = AiCalculatorUiState(isLoading = true)

            // --- Placeholder for AI backend call ---
            delay(2000) // Simulate network delay
            val result = processAiQuery(query)
            // --- End of placeholder ---

            historyRepository.addHistoryItem(
                CalculationHistory(
                    query = query,
                    result = result,
                    isAiCalculation = true
                )
            )

            _uiState.value = AiCalculatorUiState(result = result)
        }
    }

    // This is a placeholder function. In a real app, this would make a network call to an AI service.
    private fun processAiQuery(query: String): String {
        return when {
            query.contains("25% of 480") -> "120. The calculation is 0.25 * 480 = 120."
            query.lowercase().contains("square root of 289") -> "17. The square root of 289 is 17."
            query.lowercase().contains("laptop") && query.contains("1200") && query.contains("15%") -> {
                "You would pay $1020. The discount is $1200 * 0.15 = $180. The final price is $1200 - $180 = $1020."
            }
            else -> "I'm sorry, I can only answer specific pre-programmed questions in this demo."
        }
    }
}

data class AiCalculatorUiState(
    val isLoading: Boolean = false,
    val result: String? = null,
    val error: String? = null
)