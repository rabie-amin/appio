package com.example.aipoweredcalculator.navigation

import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.example.aipoweredcalculator.ui.screens.* 
import com.example.aipoweredcalculator.utils.Result
import com.example.aipoweredcalculator.viewmodel.AuthViewModel

@Composable
fun AppNavigation() {
    val navController = rememberNavController()
    val authViewModel: AuthViewModel = hiltViewModel()
    val authState by authViewModel.authState.collectAsState()

    NavHost(navController = navController, startDestination = AppScreens.Splash.route) {
        composable(AppScreens.Splash.route) {
            SplashScreen(navController = navController)
        }
        composable(AppScreens.Auth.route) {
            AuthScreen(navController = navController, authViewModel = authViewModel)
        }
        composable(AppScreens.Main.route) {
            MainScreen()
        }
    }
}