package com.example.aipoweredcalculator.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.navigation.NavController
import com.example.aipoweredcalculator.viewmodel.AuthViewModel
import com.example.aipoweredcalculator.viewmodel.SettingsViewModel
import com.example.aipoweredcalculator.navigation.AppScreens

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(
    navController: NavController,
    settingsViewModel: SettingsViewModel = hiltViewModel(),
    authViewModel: AuthViewModel = hiltViewModel()
) {
    val isDarkTheme by settingsViewModel.isDarkTheme.collectAsState()
    val language by settingsViewModel.language.collectAsState()
    val aiModel by settingsViewModel.aiModel.collectAsState()

    Scaffold(
        topBar = { TopAppBar(title = { Text("Settings") }) }
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(it)
                .verticalScroll(rememberScrollState())
        ) {
            ThemeSetting(currentTheme = isDarkTheme, isSystemDark = isSystemInDarkTheme()) {
                theme -> settingsViewModel.setTheme(theme)
            }
            Divider()
            LanguageSetting(currentLanguage = language) {
                lang -> settingsViewModel.setLanguage(lang)
            }
            Divider()
            AiModelSetting(currentModel = aiModel) {
                model -> settingsViewModel.setAiModel(model)
            }
            Divider()
            Spacer(modifier = Modifier.weight(1f))
            Button(
                onClick = {
                    authViewModel.signOut()
                    navController.navigate(AppScreens.Auth.route) {
                        popUpTo(AppScreens.Main.route) { inclusive = true }
                    }
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)
            ) {
                Text("Sign Out")
            }
        }
    }
}

@Composable
fun ThemeSetting(currentTheme: Boolean?, isSystemDark: Boolean, onThemeChange: (Boolean) -> Unit) {
    var expanded by remember { mutableStateOf(false) }
    val themeText = when(currentTheme) {
        true -> "Dark"
        false -> "Light"
        null -> "System Default"
    }

    SettingItem(title = "Theme", subtitle = themeText) {
        expanded = true
        DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
            DropdownMenuItem(text = { Text("Light") }, onClick = { onThemeChange(false); expanded = false })
            DropdownMenuItem(text = { Text("Dark") }, onClick = { onThemeChange(true); expanded = false })
        }
    }
    Switch(
        checked = currentTheme ?: isSystemDark,
        onCheckedChange = onThemeChange,
        modifier = Modifier.padding(horizontal = 16.dp)
    )
}

@Composable
fun LanguageSetting(currentLanguage: String, onLanguageChange: (String) -> Unit) {
    SettingItem(title = "Language", subtitle = currentLanguage) { /* Open language selection dialog */ }
}

@Composable
fun AiModelSetting(currentModel: String, onModelChange: (String) -> Unit) {
    SettingItem(title = "AI Model", subtitle = currentModel) { /* Open model selection dialog */ }
}

@Composable
fun SettingItem(title: String, subtitle: String, onClick: () -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(16.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(text = title, style = MaterialTheme.typography.bodyLarge)
            Text(text = subtitle, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}