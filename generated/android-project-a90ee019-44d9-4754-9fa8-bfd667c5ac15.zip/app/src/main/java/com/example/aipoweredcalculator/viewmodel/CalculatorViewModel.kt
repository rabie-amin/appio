package com.example.aipoweredcalculator.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.aipoweredcalculator.data.model.CalculationHistory
import com.example.aipoweredcalculator.data.repository.HistoryRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import net.objecthunter.exp4j.ExpressionBuilder
import javax.inject.Inject

@HiltViewModel
class CalculatorViewModel @Inject constructor(
    private val historyRepository: HistoryRepository
) : ViewModel() {

    private val _expression = MutableStateFlow("")
    val expression: StateFlow<String> = _expression.asStateFlow()

    private val _result = MutableStateFlow("")
    val result: StateFlow<String> = _result.asStateFlow()

    fun onAction(action: CalculatorAction) {
        when (action) {
            is CalculatorAction.Number -> enterNumber(action.number)
            is CalculatorAction.Decimal -> enterDecimal()
            is CalculatorAction.Clear -> {
                _expression.value = ""
                _result.value = ""
            }
            is CalculatorAction.Operation -> enterOperation(action.operation)
            is CalculatorAction.Calculate -> calculate()
            is CalculatorAction.Delete -> delete()
        }
    }

    private fun enterNumber(number: String) {
        _expression.value += number
    }

    private fun enterDecimal() {
        if (!_expression.value.contains(".") || _expression.value.substringAfterLast { it == '+' || it == '–' || it == '×' || it == '÷' }.contains(".").not()) {
            _expression.value += "."
        }
    }

    private fun enterOperation(operation: String) {
        if (_expression.value.isNotBlank() && _expression.value.last().isDigit()) {
            _expression.value += operation
        }
    }

    private fun delete() {
        if (_expression.value.isNotBlank()) {
            _expression.value = _expression.value.dropLast(1)
        }
    }

    private fun calculate() {
        val currentExpression = _expression.value
        if (currentExpression.isBlank()) return

        try {
            val expressionString = currentExpression.replace('×', '*').replace('÷', '/')
            val expression = ExpressionBuilder(expressionString).build()
            val calculationResult = expression.evaluate()
            _result.value = calculationResult.toString()

            viewModelScope.launch {
                historyRepository.addHistoryItem(
                    CalculationHistory(
                        query = currentExpression,
                        result = _result.value,
                        isAiCalculation = false
                    )
                )
            }
        } catch (e: Exception) {
            _result.value = "Error"
        }
    }
}

sealed class CalculatorAction {
    data class Number(val number: String) : CalculatorAction()
    data class Operation(val operation: String) : CalculatorAction()
    object Clear : CalculatorAction()
    object Delete : CalculatorAction()
    object Decimal : CalculatorAction()
    object Calculate : CalculatorAction()
}