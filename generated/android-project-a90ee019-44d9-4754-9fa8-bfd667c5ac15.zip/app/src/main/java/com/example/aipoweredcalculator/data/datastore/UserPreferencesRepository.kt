package com.example.aipoweredcalculator.data.datastore

import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import javax.inject.Inject

class UserPreferencesRepository @Inject constructor(private val dataStore: DataStore<Preferences>) {

    private object PreferencesKeys {
        val DARK_THEME_ENABLED = booleanPreferencesKey("dark_theme_enabled")
        val LANGUAGE = stringPreferencesKey("language")
        val AI_MODEL = stringPreferencesKey("ai_model")
    }

    val isDarkTheme: Flow<Boolean?> = dataStore.data.map {
        it[PreferencesKeys.DARK_THEME_ENABLED]
    }

    val language: Flow<String> = dataStore.data.map {
        it[PreferencesKeys.LANGUAGE] ?: "English"
    }

    val aiModel: Flow<String> = dataStore.data.map {
        it[PreferencesKeys.AI_MODEL] ?: "Basic"
    }

    suspend fun setDarkTheme(enabled: Boolean) {
        dataStore.edit {
            it[PreferencesKeys.DARK_THEME_ENABLED] = enabled
        }
    }

    suspend fun setLanguage(language: String) {
        dataStore.edit {
            it[PreferencesKeys.LANGUAGE] = language
        }
    }

    suspend fun setAiModel(model: String) {
        dataStore.edit {
            it[PreferencesKeys.AI_MODEL] = model
        }
    }
}