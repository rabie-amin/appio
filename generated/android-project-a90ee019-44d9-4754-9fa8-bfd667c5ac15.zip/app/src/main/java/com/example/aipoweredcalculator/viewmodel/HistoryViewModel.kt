package com.example.aipoweredcalculator.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.aipoweredcalculator.data.model.CalculationHistory
import com.example.aipoweredcalculator.data.repository.HistoryRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class HistoryViewModel @Inject constructor(
    private val repository: HistoryRepository
) : ViewModel() {

    private val _historyState = MutableStateFlow<List<CalculationHistory>>(emptyList())
    val historyState: StateFlow<List<CalculationHistory>> = _historyState

    init {
        loadHistory()
    }

    fun loadHistory() {
        viewModelScope.launch {
            _historyState.value = repository.getHistory()
        }
    }

    fun deleteHistoryItem(item: CalculationHistory) {
        viewModelScope.launch {
            repository.deleteHistoryItem(item.id)
            loadHistory() // Refresh list
        }
    }

    fun clearAllHistory() {
        viewModelScope.launch {
            repository.clearHistory()
            _historyState.value = emptyList()
        }
    }
}